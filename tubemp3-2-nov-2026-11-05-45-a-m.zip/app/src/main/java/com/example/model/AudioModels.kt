package com.example.model

enum class AudioQuality(
    val bitrate: Int,
    val label: String,
    val description: String,
    val approxMbPerMinute: Float
) {
    MP3_320(320, "320 kbps", "Ultra HQ · Máxima fidelidad de estudio", 2.4f),
    MP3_256(256, "256 kbps", "Alta Definición · Excelente para audífonos", 1.9f),
    MP3_192(192, "192 kbps", "Estándar · Recomendado equilibrado", 1.4f),
    MP3_128(128, "128 kbps", "Descarga Rápida · Peso ligero", 0.96f),
    MP3_64(64, "64 kbps", "Ahorro de Datos · Ultra liviano", 0.48f);

    fun estimateFileSizeMb(durationSeconds: Long): Float {
        val minutes = (durationSeconds.coerceAtLeast(60)).toFloat() / 60f
        return String.format(java.util.Locale.US, "%.1f", minutes * approxMbPerMinute).toFloat()
    }
}

enum class AudioFormat(val extension: String, val mimeType: String, val displayName: String) {
    MP3("mp3", "audio/mpeg", "MP3 Audio (.mp3)"),
    M4A("m4a", "audio/mp4", "AAC / M4A (.m4a)")
}

data class YouTubeVideo(
    val id: String,
    val title: String,
    val author: String,
    val durationSeconds: Long,
    val viewCount: String,
    val thumbnailUrl: String,
    val uploadDate: String = "2025"
) {
    val durationFormatted: String
        get() {
            val minutes = durationSeconds / 60
            val seconds = durationSeconds % 60
            return String.format(java.util.Locale.US, "%d:%02d", minutes, seconds)
        }

    val youtubeUrl: String
        get() = "https://www.youtube.com/watch?v=$id"
}

enum class DownloadStatus {
    QUEUED,
    DOWNLOADING,
    COMPLETED,
    PAUSED,
    ERROR
}

data class DownloadItem(
    val id: String,
    val videoId: String,
    val title: String,
    val author: String,
    val thumbnailUrl: String,
    val quality: AudioQuality,
    val format: AudioFormat,
    val filePath: String,
    val fileSizeBytes: Long = 0L,
    val progress: Float = 0f,
    val status: DownloadStatus = DownloadStatus.QUEUED,
    val speedText: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val durationSeconds: Long = 0L,
    val errorMessage: String? = null
) {
    val fileSizeFormatted: String
        get() {
            if (fileSizeBytes <= 0) return "${quality.estimateFileSizeMb(durationSeconds)} MB"
            val mb = fileSizeBytes.toDouble() / (1024 * 1024)
            return String.format(java.util.Locale.US, "%.2f MB", mb)
        }
}

data class PlayerState(
    val currentTrackTitle: String = "",
    val currentArtist: String = "",
    val currentThumbnailUrl: String = "",
    val isPlaying: Boolean = false,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val isBuffering: Boolean = false,
    val playbackSpeed: Float = 1.0f,
    val isRepeatEnabled: Boolean = false,
    val localFilePath: String? = null,
    val videoId: String? = null
) {
    val progress: Float
        get() = if (durationMs > 0) (currentPositionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f

    val positionFormatted: String
        get() = formatTime(currentPositionMs)

    val durationFormatted: String
        get() = formatTime(durationMs)

    private fun formatTime(ms: Long): String {
        val totalSecs = (ms / 1000).coerceAtLeast(0)
        val mins = totalSecs / 60
        val secs = totalSecs % 60
        return String.format(java.util.Locale.US, "%d:%02d", mins, secs)
    }
}
