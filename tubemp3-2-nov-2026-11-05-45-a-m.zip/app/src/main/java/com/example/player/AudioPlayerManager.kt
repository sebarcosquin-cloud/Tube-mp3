package com.example.player

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.example.model.DownloadItem
import com.example.model.PlayerState
import com.example.model.YouTubeVideo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.io.File

class AudioPlayerManager(private val context: Context) {
    companion object {
        private const val TAG = "AudioPlayerManager"
    }

    private var mediaPlayer: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())

    private val _playerState = MutableStateFlow(PlayerState())
    val playerState: StateFlow<PlayerState> = _playerState.asStateFlow()

    private val progressUpdater = object : Runnable {
        override fun run() {
            mediaPlayer?.let { mp ->
                if (mp.isPlaying) {
                    _playerState.update {
                        it.copy(
                            currentPositionMs = mp.currentPosition.toLong(),
                            durationMs = mp.duration.toLong().coerceAtLeast(1L)
                        )
                    }
                    handler.postDelayed(this, 300)
                }
            }
        }
    }

    fun playDownloadedTrack(item: DownloadItem) {
        val file = File(item.filePath)
        if (!file.exists()) {
            Log.e(TAG, "File does not exist: ${item.filePath}")
            return
        }

        releasePlayer()

        try {
            val mp = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(file.absolutePath)
                prepare()
                start()
            }

            mediaPlayer = mp
            _playerState.value = PlayerState(
                currentTrackTitle = item.title,
                currentArtist = item.author,
                currentThumbnailUrl = item.thumbnailUrl,
                isPlaying = true,
                currentPositionMs = 0L,
                durationMs = mp.duration.toLong().coerceAtLeast(1L),
                localFilePath = item.filePath,
                videoId = item.videoId
            )

            mp.setOnCompletionListener {
                if (_playerState.value.isRepeatEnabled) {
                    mp.seekTo(0)
                    mp.start()
                } else {
                    _playerState.update { it.copy(isPlaying = false, currentPositionMs = 0L) }
                }
            }

            handler.post(progressUpdater)
        } catch (e: Exception) {
            Log.e(TAG, "Error playing audio file", e)
        }
    }

    fun playVideoPreview(video: YouTubeVideo) {
        releasePlayer()

        // Preview stream fallback or ambient audio
        _playerState.value = PlayerState(
            currentTrackTitle = video.title,
            currentArtist = video.author,
            currentThumbnailUrl = video.thumbnailUrl,
            isPlaying = true,
            currentPositionMs = 0L,
            durationMs = video.durationSeconds * 1000L,
            videoId = video.id
        )

        try {
            // Simulated preview tone generator or direct stream preview
            val mp = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
            }
            // If external URL or stream, setDataSource; otherwise simulate playback progress
            mediaPlayer = mp
            handler.post(progressUpdater)
        } catch (e: Exception) {
            Log.w(TAG, "Preview audio init: ${e.message}")
        }
    }

    fun togglePlayPause() {
        val mp = mediaPlayer
        if (mp != null) {
            if (mp.isPlaying) {
                mp.pause()
                _playerState.update { it.copy(isPlaying = false) }
                handler.removeCallbacks(progressUpdater)
            } else {
                mp.start()
                _playerState.update { it.copy(isPlaying = true) }
                handler.post(progressUpdater)
            }
        } else {
            // Simulated toggle if playing preview
            val current = _playerState.value
            if (current.currentTrackTitle.isNotEmpty()) {
                val nextPlay = !current.isPlaying
                _playerState.update { it.copy(isPlaying = nextPlay) }
                if (nextPlay) {
                    handler.post(progressUpdater)
                } else {
                    handler.removeCallbacks(progressUpdater)
                }
            }
        }
    }

    fun seekToFraction(fraction: Float) {
        val targetMs = (_playerState.value.durationMs * fraction.coerceIn(0f, 1f)).toLong()
        seekToMs(targetMs)
    }

    fun seekToMs(positionMs: Long) {
        mediaPlayer?.let { mp ->
            try {
                mp.seekTo(positionMs.toInt())
            } catch (e: Exception) {
                Log.w(TAG, "Seek error", e)
            }
        }
        _playerState.update { it.copy(currentPositionMs = positionMs) }
    }

    fun seekRelative(seconds: Int) {
        val current = _playerState.value.currentPositionMs
        val target = (current + seconds * 1000L).coerceIn(0L, _playerState.value.durationMs.coerceAtLeast(1L))
        seekToMs(target)
    }

    fun cyclePlaybackSpeed() {
        val speeds = listOf(0.75f, 1.0f, 1.25f, 1.5f)
        val current = _playerState.value.playbackSpeed
        val nextIndex = (speeds.indexOf(current) + 1) % speeds.size
        val newSpeed = speeds[nextIndex]

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            mediaPlayer?.let { mp ->
                try {
                    val params = mp.playbackParams
                    params.speed = newSpeed
                    mp.playbackParams = params
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to set playback speed", e)
                }
            }
        }
        _playerState.update { it.copy(playbackSpeed = newSpeed) }
    }

    fun toggleRepeat() {
        _playerState.update { it.copy(isRepeatEnabled = !it.isRepeatEnabled) }
    }

    fun stop() {
        releasePlayer()
        _playerState.value = PlayerState()
    }

    private fun releasePlayer() {
        handler.removeCallbacks(progressUpdater)
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (e: Exception) {
            // Ignore
        }
        mediaPlayer = null
    }
}
