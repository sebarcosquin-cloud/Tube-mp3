package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.DownloadStatus
import com.example.ui.components.FullPlayerSheet
import com.example.ui.components.MiniPlayerBar
import com.example.ui.components.QualitySelectorBottomSheet
import com.example.ui.screens.DownloadsScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.BorderDark
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.RedPrimary
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevatedDark
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.viewmodel.MainViewModel
import com.example.viewmodel.NavigationTab

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val downloads by viewModel.downloads.collectAsState()
    val filteredDownloads by viewModel.filteredDownloads.collectAsState()
    val playerState by viewModel.playerState.collectAsState()
    val totalStorageBytes by viewModel.totalStorageBytes.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        viewModel.userMessage.collect { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    // Back handling: if in sub-tab, go back to explore; if full player open, minimize it
    if (uiState.isFullPlayerOpen) {
        BackHandler {
            viewModel.setFullPlayerOpen(false)
        }
    } else if (uiState.currentTab != NavigationTab.EXPLORE) {
        BackHandler {
            viewModel.onTabSelected(NavigationTab.EXPLORE)
        }
    }

    val activeDownloadsCount = downloads.count { it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.QUEUED }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark),
        containerColor = BackgroundDark,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            // App Branding Header
            Surface(
                color = BackgroundDark,
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Custom App Icon / Brand
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(RedPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Headphones,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Tube",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Black,
                                color = TextPrimaryDark,
                                fontSize = 20.sp
                            )
                            Text(
                                text = "MP3",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Black,
                                color = RedPrimary,
                                fontSize = 20.sp
                            )
                        }
                        Text(
                            text = "Descargador de audio YouTube",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondaryDark,
                            fontSize = 11.sp
                        )
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    // Active Downloads Pill if any
                    if (activeDownloadsCount > 0) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = RedPrimary.copy(alpha = 0.2f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, RedPrimary),
                            modifier = Modifier.clip(RoundedCornerShape(20.dp))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Download,
                                    contentDescription = null,
                                    tint = RedPrimary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "$activeDownloadsCount descargando",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = RedPrimary
                                )
                            }
                        }
                    }
                }
            }
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
            ) {
                // Persistent Mini Player above NavigationBar
                AnimatedVisibility(
                    visible = playerState.currentTrackTitle.isNotEmpty() && !uiState.isFullPlayerOpen,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    MiniPlayerBar(
                        playerState = playerState,
                        onTogglePlayPause = { viewModel.togglePlayPause() },
                        onBarClick = { viewModel.setFullPlayerOpen(true) },
                        onCloseClick = { viewModel.stopPlayer() }
                    )
                }

                // Standard M3 Navigation Bar
                NavigationBar(
                    containerColor = SurfaceDark,
                    contentColor = TextPrimaryDark,
                    tonalElevation = 8.dp,
                    modifier = Modifier.testTag("bottom_nav_bar")
                ) {
                    // Tab 1: Buscar
                    NavigationBarItem(
                        selected = uiState.currentTab == NavigationTab.EXPLORE,
                        onClick = { viewModel.onTabSelected(NavigationTab.EXPLORE) },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Buscar"
                            )
                        },
                        label = { Text("Buscar") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = RedPrimary,
                            indicatorColor = RedPrimary,
                            unselectedIconColor = TextSecondaryDark,
                            unselectedTextColor = TextSecondaryDark
                        ),
                        modifier = Modifier.testTag("nav_explore")
                    )

                    // Tab 2: Descargas
                    NavigationBarItem(
                        selected = uiState.currentTab == NavigationTab.DOWNLOADS,
                        onClick = { viewModel.onTabSelected(NavigationTab.DOWNLOADS) },
                        icon = {
                            if (activeDownloadsCount > 0) {
                                BadgedBox(
                                    badge = {
                                        Badge(containerColor = RedPrimary) {
                                            Text(activeDownloadsCount.toString())
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Download,
                                        contentDescription = "Descargas"
                                    )
                                }
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Download,
                                    contentDescription = "Descargas"
                                )
                            }
                        },
                        label = { Text("Descargas") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = RedPrimary,
                            indicatorColor = RedPrimary,
                            unselectedIconColor = TextSecondaryDark,
                            unselectedTextColor = TextSecondaryDark
                        ),
                        modifier = Modifier.testTag("nav_downloads")
                    )

                    // Tab 3: Biblioteca
                    NavigationBarItem(
                        selected = uiState.currentTab == NavigationTab.LIBRARY,
                        onClick = { viewModel.onTabSelected(NavigationTab.LIBRARY) },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.LibraryMusic,
                                contentDescription = "Biblioteca"
                            )
                        },
                        label = { Text("Biblioteca") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = RedPrimary,
                            indicatorColor = RedPrimary,
                            unselectedIconColor = TextSecondaryDark,
                            unselectedTextColor = TextSecondaryDark
                        ),
                        modifier = Modifier.testTag("nav_library")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (uiState.currentTab) {
                NavigationTab.EXPLORE -> {
                    SearchScreen(
                        uiState = uiState,
                        onQueryChange = { viewModel.onSearchQueryChanged(it) },
                        onSearch = { viewModel.performSearch(it) },
                        onPasteUrl = { viewModel.pasteAndAnalyzeUrl() },
                        onCategorySelect = { viewModel.selectCategory(it) },
                        onDownloadClick = { viewModel.openQualitySelector(it) },
                        onPreviewClick = { viewModel.previewTrack(it) }
                    )
                }
                NavigationTab.DOWNLOADS -> {
                    DownloadsScreen(
                        downloads = filteredDownloads,
                        totalStorageBytes = totalStorageBytes,
                        selectedFilter = uiState.downloadFilter,
                        onFilterSelect = { viewModel.setDownloadFilter(it) },
                        onPlayTrack = { viewModel.playTrack(it) },
                        onPauseDownload = { viewModel.pauseDownload(it) },
                        onResumeDownload = { viewModel.resumeDownload(it) },
                        onCancelOrDelete = { viewModel.cancelOrDeleteDownload(it) },
                        onShareTrack = { viewModel.shareDownloadedFile(it) },
                        onNavigateToSearch = { viewModel.onTabSelected(NavigationTab.EXPLORE) }
                    )
                }
                NavigationTab.LIBRARY -> {
                    LibraryScreen(
                        downloads = downloads,
                        playerState = playerState,
                        onPlayTrack = { viewModel.playTrack(it) },
                        onNavigateToSearch = { viewModel.onTabSelected(NavigationTab.EXPLORE) }
                    )
                }
            }

            // Quality / Resolution Selector Modal Bottom Sheet
            if (uiState.qualityDialog.isOpen) {
                QualitySelectorBottomSheet(
                    video = uiState.qualityDialog.video,
                    selectedQuality = uiState.qualityDialog.selectedQuality,
                    selectedFormat = uiState.qualityDialog.selectedFormat,
                    onQualitySelected = { viewModel.setDialogQuality(it) },
                    onFormatSelected = { viewModel.setDialogFormat(it) },
                    onConfirmDownload = { viewModel.confirmDownload() },
                    onDismiss = { viewModel.closeQualitySelector() }
                )
            }

            // Full Player Modal Sheet
            FullPlayerSheet(
                playerState = playerState,
                isOpen = uiState.isFullPlayerOpen,
                onDismiss = { viewModel.setFullPlayerOpen(false) },
                onTogglePlayPause = { viewModel.togglePlayPause() },
                onSeek = { viewModel.seekToFraction(it) },
                onSeekRelative = { viewModel.seekRelative(it) },
                onCycleSpeed = { viewModel.cyclePlaybackSpeed() },
                onToggleRepeat = { viewModel.toggleRepeat() }
            )
        }
    }
}
