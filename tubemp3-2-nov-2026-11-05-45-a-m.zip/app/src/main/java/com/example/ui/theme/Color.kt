package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary YouTube / Modern Music Palette
val RedPrimary = Color(0xFFFF2A42)
val RedDark = Color(0xFFC70024)
val RedContainer = Color(0xFF3E000B)
val OnRedPrimary = Color(0xFFFFFFFF)

val GoldAccent = Color(0xFFFFB800)
val GoldContainer = Color(0xFF382A00)

// Dark Theme Surfaces
val BackgroundDark = Color(0xFF0F0F14)
val SurfaceDark = Color(0xFF16161F)
val SurfaceElevatedDark = Color(0xFF20202C)
val SurfaceCard = Color(0xFF262636)
val BorderDark = Color(0xFF333348)

val TextPrimaryDark = Color(0xFFF2F2F7)
val TextSecondaryDark = Color(0xFFA0A0B2)
val TextTertiaryDark = Color(0xFF707085)

// Status Colors
val SuccessGreen = Color(0xFF22C55E)
val WarningOrange = Color(0xFFF97316)
val ErrorRed = Color(0xFFEF4444)
