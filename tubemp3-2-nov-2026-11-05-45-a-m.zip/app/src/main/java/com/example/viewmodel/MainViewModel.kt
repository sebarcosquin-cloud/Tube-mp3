package com.example.viewmodel

import android.app.Application
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.downloader.DownloadManagerRepository
import com.example.model.AudioFormat
import com.example.model.AudioQuality
import com.example.model.DownloadItem
import com.example.model.DownloadStatus
import com.example.model.PlayerState
import com.example.model.YouTubeVideo
import com.example.network.YouTubeSearchRepository
import com.example.player.AudioPlayerManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class NavigationTab(val title: String) {
    EXPLORE("Buscar"),
    DOWNLOADS("Descargas"),
    LIBRARY("Biblioteca")
}

enum class DownloadFilter {
    ALL,
    COMPLETED,
    ACTIVE
}

data class QualityDialogState(
    val isOpen: Boolean = false,
    val video: YouTubeVideo? = null,
    val selectedQuality: AudioQuality = AudioQuality.MP3_320,
    val selectedFormat: AudioFormat = AudioFormat.MP3
)

data class UiState(
    val currentTab: NavigationTab = NavigationTab.EXPLORE,
    val searchQuery: String = "",
    val isSearching: Boolean = false,
    val searchResults: List<YouTubeVideo> = emptyList(),
    val suggestions: List<String> = emptyList(),
    val detectedUrl: String? = null,
    val selectedCategory: String = "Tendencias",
    val downloadFilter: DownloadFilter = DownloadFilter.ALL,
    val qualityDialog: QualityDialogState = QualityDialogState(),
    val isFullPlayerOpen: Boolean = false
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val searchRepo = YouTubeSearchRepository()
    private val downloadRepo = DownloadManagerRepository(application)
    private val playerManager = AudioPlayerManager(application)

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    val downloads: StateFlow<List<DownloadItem>> = downloadRepo.downloads
    val playerState: StateFlow<PlayerState> = playerManager.playerState

    private val _userMessage = MutableSharedFlow<String>()
    val userMessage: SharedFlow<String> = _userMessage.asSharedFlow()

    private var searchJob: Job? = null
    private var suggestionJob: Job? = null

    // Combined filtered downloads
    val filteredDownloads: StateFlow<List<DownloadItem>> = combine(_uiState, downloads) { state, items ->
        when (state.downloadFilter) {
            DownloadFilter.ALL -> items
            DownloadFilter.COMPLETED -> items.filter { it.status == DownloadStatus.COMPLETED }
            DownloadFilter.ACTIVE -> items.filter { it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.QUEUED }
        }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val totalStorageBytes: StateFlow<Long> = downloads.combine(_uiState) { items, _ ->
        items.filter { it.status == DownloadStatus.COMPLETED }.sumOf { it.fileSizeBytes }
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0L)

    init {
        loadInitialCatalog()
        checkClipboardForYouTubeUrl()
    }

    private fun loadInitialCatalog() {
        viewModelScope.launch {
            _uiState.update { it.copy(isSearching = true) }
            val list = searchRepo.getTrendingTracks()
            _uiState.update {
                it.copy(
                    searchResults = list,
                    isSearching = false
                )
            }
        }
    }

    fun onTabSelected(tab: NavigationTab) {
        _uiState.update { it.copy(currentTab = tab) }
    }

    fun onSearchQueryChanged(newQuery: String) {
        _uiState.update {
            it.copy(
                searchQuery = newQuery,
                detectedUrl = searchRepo.extractVideoId(newQuery)?.let { newQuery }
            )
        }

        suggestionJob?.cancel()
        if (newQuery.trim().length >= 2) {
            suggestionJob = viewModelScope.launch {
                delay(200)
                val suggestions = searchRepo.getSuggestions(newQuery)
                _uiState.update { it.copy(suggestions = suggestions) }
            }
        } else {
            _uiState.update { it.copy(suggestions = emptyList()) }
        }
    }

    fun performSearch(query: String? = null) {
        val q = query ?: _uiState.value.searchQuery
        _uiState.update { it.copy(searchQuery = q, suggestions = emptyList()) }

        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            _uiState.update { it.copy(isSearching = true) }
            val results = searchRepo.searchVideos(q)
            _uiState.update {
                it.copy(
                    searchResults = results,
                    isSearching = false
                )
            }
        }
    }

    fun selectCategory(category: String) {
        _uiState.update { it.copy(selectedCategory = category) }
        val searchKey = when (category) {
            "Tendencias" -> ""
            "Top Hits" -> "Top Hits 2026"
            "Reggaeton" -> "Reggaeton 2026"
            "Rock" -> "Rock Classics"
            "Lo-Fi" -> "lofi hip hop radio"
            "Pop" -> "Pop Latino"
            "Acústico" -> "Acústico guitarra"
            else -> category
        }
        performSearch(searchKey)
    }

    fun checkClipboardForYouTubeUrl() {
        try {
            val clipboard = getApplication<Application>().getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            if (clipboard != null && clipboard.hasPrimaryClip() &&
                clipboard.primaryClipDescription?.hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN) == true
            ) {
                val clipText = clipboard.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
                val videoId = searchRepo.extractVideoId(clipText)
                if (videoId != null) {
                    _uiState.update { it.copy(detectedUrl = clipText) }
                }
            }
        } catch (e: Exception) {
            // Ignore clipboard errors
        }
    }

    fun pasteAndAnalyzeUrl() {
        val url = _uiState.value.detectedUrl
        if (url != null) {
            _uiState.update { it.copy(searchQuery = url) }
            performSearch(url)
        } else {
            try {
                val clipboard = getApplication<Application>().getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                val clipText = clipboard?.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
                if (clipText.isNotBlank()) {
                    _uiState.update { it.copy(searchQuery = clipText) }
                    performSearch(clipText)
                }
            } catch (e: Exception) {
                // Ignore
            }
        }
    }

    fun openQualitySelector(video: YouTubeVideo) {
        _uiState.update {
            it.copy(
                qualityDialog = QualityDialogState(
                    isOpen = true,
                    video = video,
                    selectedQuality = AudioQuality.MP3_320,
                    selectedFormat = AudioFormat.MP3
                )
            )
        }
    }

    fun closeQualitySelector() {
        _uiState.update { it.copy(qualityDialog = it.qualityDialog.copy(isOpen = false)) }
    }

    fun setDialogQuality(quality: AudioQuality) {
        _uiState.update { it.copy(qualityDialog = it.qualityDialog.copy(selectedQuality = quality)) }
    }

    fun setDialogFormat(format: AudioFormat) {
        _uiState.update { it.copy(qualityDialog = it.qualityDialog.copy(selectedFormat = format)) }
    }

    fun confirmDownload() {
        val dialog = _uiState.value.qualityDialog
        val video = dialog.video ?: return

        downloadRepo.startDownload(video, dialog.selectedQuality, dialog.selectedFormat)
        closeQualitySelector()

        viewModelScope.launch {
            _userMessage.emit("Descargando \"${video.title}\" en ${dialog.selectedQuality.label}")
        }
    }

    fun setDownloadFilter(filter: DownloadFilter) {
        _uiState.update { it.copy(downloadFilter = filter) }
    }

    fun pauseDownload(id: String) {
        downloadRepo.pauseDownload(id)
    }

    fun resumeDownload(id: String) {
        downloadRepo.resumeDownload(id)
    }

    fun cancelOrDeleteDownload(id: String) {
        downloadRepo.cancelOrDeleteDownload(id)
    }

    fun shareDownloadedFile(item: DownloadItem) {
        downloadRepo.shareDownloadedFile(item)
    }

    // Audio Player Controls
    fun playTrack(item: DownloadItem) {
        playerManager.playDownloadedTrack(item)
    }

    fun previewTrack(video: YouTubeVideo) {
        playerManager.playVideoPreview(video)
        viewModelScope.launch {
            _userMessage.emit("Reproduciendo vista previa de \"${video.title}\"")
        }
    }

    fun togglePlayPause() {
        playerManager.togglePlayPause()
    }

    fun seekToFraction(fraction: Float) {
        playerManager.seekToFraction(fraction)
    }

    fun seekRelative(seconds: Int) {
        playerManager.seekRelative(seconds)
    }

    fun cyclePlaybackSpeed() {
        playerManager.cyclePlaybackSpeed()
    }

    fun toggleRepeat() {
        playerManager.toggleRepeat()
    }

    fun setFullPlayerOpen(isOpen: Boolean) {
        _uiState.update { it.copy(isFullPlayerOpen = isOpen) }
    }

    fun stopPlayer() {
        playerManager.stop()
    }

    override fun onCleared() {
        super.onCleared()
        playerManager.stop()
    }
}
